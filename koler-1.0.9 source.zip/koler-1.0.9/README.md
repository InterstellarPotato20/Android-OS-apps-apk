# Koler

** An update, im currently working on a massive code redesign from scratch, will probably take some time, but will be better

A uniquely stylized phone app for Android, designed with the user in mind.
Believe us we want to make it good, as we use it ourselves.
</br>

## Support
Due to lack of support, unfortunately it's diffictult for us to keep supporting the project
If you like the app and want us to fix and improve it, please consider giving us a boost
</br>

<a href="https://paypal.me/theroeiedri?locale.x=en_US"><img src="https://www.paypalobjects.com/webstatic/paypalme/images/social/pplogo384.png" alt="Paypal.me" width="190px"></a>

<img src="https://github.com/Chooloo/call_manage/blob/master/art/screenshots.png" height="250">

## Support Availablity
We are aware the app needs more support and updates, due to feature requests and minor bugs
We are currently not fully availale for supporting the app due to lack of support (The app is free to use)
We'll do our best to slowly push updates and add requested feature
If you want to help us and support us so we can put more attention into the app, please consider supporting us (Bottom of the page)
Feel free to contact us for every little thing

## GET THE APP
 * Download it from Github under [Releases](https://github.com/Chooloo/call_manage/releases "Releases")

